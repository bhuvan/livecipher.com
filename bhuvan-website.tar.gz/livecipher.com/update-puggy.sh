sh create-tar.sh
rsync -av --rsh=/usr/bin/ssh .  puggy.symonds.net:/home/bhuvan/public_html/
