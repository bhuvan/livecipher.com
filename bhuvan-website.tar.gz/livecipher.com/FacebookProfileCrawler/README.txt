Welcome to Facebook Crawler 1.0!
--------------------------------

This software requires:

- PHP 5
- openssl extension in PHP must be enabled

You should make the folder where you upload these files to writable. In other words, if you upload these to your PHP server at:

http://www.yourdomain.com/path/to/folder/

That folder should be writable by PHP (usually CHMOD 755 or 777).

Here's how it works: just open "index.php" in your browser, and input your facebook email address and password. The software will scan all of your friends, and extract their contact information into a .csv file, which you can then import into applications like MS Outlook.

This software is FREE and open-source. I hope that you will consider purchasing one or more scripts from www.TUFaT.com to support the development cause.

(c) 2009 TUFaT.com, All Rights Reserved

Thanks for using it!
Darren