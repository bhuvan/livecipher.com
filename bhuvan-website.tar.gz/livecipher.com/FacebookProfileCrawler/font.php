<?php
$GLOBALS['char_global_mas'] = Array (
	/* a - DONE */
	Array("char"=>Array(
		Array(0,9,9,9,0),
		Array(0,0,0,0,9),
		Array(0,9,9,9,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(0,9,9,9,9)
		), "size"=>Array(5,6)),
	/* b - DONE */
	Array("char"=>Array(
		Array(9,0,0,0,0),
		Array(9,0,0,0,0),
		Array(9,9,9,9,0),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,9,9,9,0)
		), "size"=>Array(5,8)),
	
	/* c  - DONE */
	Array("char"=>Array(
		Array(0,9,9,9,9),
		Array(9,0,0,0,0),
		Array(9,0,0,0,0),
		Array(9,0,0,0,0),
		Array(9,0,0,0,0),
		Array(0,9,9,9,9)
		), "size"=>Array(5,6)),
	
	/* d - DONE */
	Array("char"=>Array(
		Array(0,0,0,0,9),
		Array(0,0,0,0,9),
		Array(0,9,9,9,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(0,9,9,9,9)
		), "size"=>Array(5,8)),
	
	/* e - DONE */
	Array("char"=>Array(
		Array(0,9,9,9,0),
		Array(9,0,0,0,9),
		Array(9,9,9,9,9),
		Array(9,0,0,0,0),
		Array(9,0,0,0,9),
		Array(0,9,9,9,9)
		), "size"=>Array(5,6)),
	
	/* f - DONE */
	Array("char"=>Array(
		Array(0,0,9,9),
		Array(0,9,0,0),
		Array(9,9,9,0),
		Array(0,9,0,0),
		Array(0,9,0,0),
		Array(0,9,0,0),
		Array(0,9,0,0),
		Array(0,9,0,0)
		), "size"=>Array(4,9)),
	
	/* g - DONE */
	Array("char"=>Array(
		Array(0,9,9,9,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(0,9,9,9,9),
		Array(0,0,0,0,9),
		Array(0,9,9,9,0)
		), "size"=>Array(5,8)),
	
	/* h - DONE */
	Array("char"=>Array(
		Array(9,0,0,0,0),
		Array(9,0,0,0,0),
		Array(9,9,9,9,0),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9)
		), "size"=>Array(5,8)),
	
	/* i - DONE */
	Array("char"=>Array(
		Array(9),
		Array(0),
		Array(9),
		Array(9),
		Array(9),
		Array(9),
		Array(9),
		Array(9)
		), "size"=>Array(1,8)),
	
	/* j - DONE */
	Array("char"=>Array(
		Array(0,0,9),
		Array(0,0,0),
		Array(0,9,9),
		Array(0,0,9),
		Array(0,0,9),
		Array(0,0,9),
		Array(0,0,9),
		Array(0,0,9),
		Array(0,0,9),
		Array(9,9,0)
		), "size"=>Array(3,10)),
	
	/* k - DONE */
	Array("char"=>Array(
		Array(9,0,0,0,0),
		Array(9,0,0,0,0),
		Array(9,0,0,9,0),
		Array(9,0,9,0,0),
		Array(9,9,0,0,0),
		Array(9,0,9,0,0),
		Array(9,0,0,9,0),
		Array(9,0,0,9,9)
		), "size"=>Array(5,8)),
		
	/* p - DONE */
	Array("char"=>Array(
		Array(9,9,9,9,0),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,9,9,9,0),
		Array(9,0,0,0,0),
		Array(9,0,0,0,0)
		), "size"=>Array(5,8)),
		
	/* l - DONE */
	Array("char"=>Array(
		Array(9),
		Array(9),
		Array(9),
		Array(9),
		Array(9),
		Array(9),
		Array(9),
		Array(9)
		), "size"=>Array(1,8)),
	
	/* m - DONE */
	Array("char"=>Array(
		Array(9,9,9,9,0,9,9,9,0),
		Array(9,0,0,0,9,0,0,0,9),
		Array(9,0,0,0,9,0,0,0,9),
		Array(9,0,0,0,9,0,0,0,9),
		Array(9,0,0,0,9,0,0,0,9),
		Array(9,0,0,0,9,0,0,0,9)
		), "size"=>Array(9,6)),
	
	/* n - DONE */
	Array("char"=>Array(
		Array(9,9,9,9,0),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9)
		), "size"=>Array(5,6)),
	
	/* o - DONE */
	Array("char"=>Array(
		Array(0,9,9,9,0),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(0,9,9,9,0)
		), "size"=>Array(5,6)),
	
	/* q */
	Array("char"=>Array(
		Array(0,9,9,9,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(0,9,9,9,9),
		Array(0,0,0,0,9),
		Array(0,0,0,0,9)
		), "size"=>Array(5,8)),
	
	/* r - DONE */
	Array("char"=>Array(
		Array(9,9,9),
		Array(9,0,0),
		Array(9,0,0),
		Array(9,0,0),
		Array(9,0,0),
		Array(9,0,0)
		), "size"=>Array(3,6)),
	
	/* s - DONE */
	Array("char"=>Array(
		Array(0,9,9,9),
		Array(9,0,0,0),
		Array(0,9,9,0),
		Array(0,0,0,9),
		Array(0,0,0,9),
		Array(9,9,9,0)
		), "size"=>Array(4,6)),
	/* t - DONE */
	Array("char"=>Array(
		Array(0,9,0,0),
		Array(0,9,0,0),
		Array(9,9,9,9),
		Array(0,9,0,0),
		Array(0,9,0,0),
		Array(0,9,0,0),
		Array(0,9,0,0),
		Array(0,9,9,9)
		), "size"=>Array(4,8)),
	
	/* u - DONE */
	Array("char"=>Array(
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(0,9,9,9,9),
		), "size"=>Array(5,6)),
	
	/* v  - DONE */
	Array("char"=>Array(
		Array(9,0,0,0,9),
		Array(0,9,0,0,9),
		Array(0,9,0,0,9),
		Array(0,9,0,9,0),
		Array(0,0,9,9,0),
		Array(0,0,9,0,0),
		), "size"=>Array(5,6)),
	
	/* w - DONE */
	Array("char"=>Array(
		Array(9,0,0,0,9,0,0,9),
		Array(0,9,0,9,9,0,0,9),
		Array(0,9,0,9,0,0,0,9),
		Array(0,9,0,0,0,9,9,0),
		Array(0,9,9,0,0,9,9,0),
		Array(0,0,9,0,0,0,9,0),
		), "size"=>Array(8,6)),
	
	/* x - DONE */
	Array("char"=>Array(
		Array(9,9,0,0,9),
		Array(0,9,0,9,0),
		Array(0,0,9,9,0),
		Array(0,0,9,9,0),
		Array(0,9,0,9,0),
		Array(9,9,0,0,9),
		), "size"=>Array(5,6)),
	/* y  - DONE */
	Array("char"=>Array(
		Array(9,0,0,0,9),
		Array(0,9,0,0,9),
		Array(0,9,0,0,9),
		Array(0,0,0,9,0),
		Array(0,0,9,9,0),
		Array(0,0,9,0,0),
		Array(0,0,9,0,0),
		Array(0,9,0,0,0)
		), "size"=>Array(4,8)),
	
	/* z - DONE */
	Array("char"=>Array(
		Array(9,9,9,9,9),
		Array(0,0,0,9,0),
		Array(0,0,9,0,0),
		Array(0,9,9,0,0),
		Array(0,9,0,0,0),
		Array(9,9,9,9,9)
		), "size"=>Array(4,6)),
	
	/* @ - DONE  */
	Array("char"=>Array(
		Array(0,0,0,9,9,9,9,0,0),
		Array(0,9,0,0,0,0,0,9,0),
		Array(9,0,0,9,9,9,9,0,9),
		Array(9,0,9,0,0,0,9,0,9),
		Array(9,0,9,0,0,0,9,0,9),
		Array(9,0,9,0,0,0,9,0,9),
		Array(9,0,0,9,9,0,9,9,0),
		Array(0,9,9,0,0,0,0,0,0),
		Array(0,0,0,9,9,9,9,0,0)
		), "size"=>Array(9,9)),
	
	/* 0 - DONE */
	Array("char"=>Array(
		Array(0,9,9,9,0),
		Array(9,0,0,0,0),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,0),
		Array(0,9,9,9,0),
		), "size"=>Array(5,8)),
	
	/* 1 - DONE */
	Array("char"=>Array(
		Array(0,0,9,0),
		Array(9,9,9,0),
		Array(0,0,9,0),
		Array(0,0,9,0),
		Array(0,0,9,0),
		Array(0,0,9,0),
		Array(0,0,9,0),
		Array(9,9,9,9)
		), "size"=>Array(4,8)),
	
	/* 2 - DONE */
	Array("char"=>Array(
		Array(0,9,9,9,0),
		Array(0,0,0,0,9),
		Array(0,0,0,0,9),
		Array(0,0,0,0,9),
		Array(0,0,0,9,0),
		Array(0,0,9,0,0),
		Array(0,9,0,0,0),
		Array(9,9,9,9,9)
		), "size"=>Array(5,8)),
	
	/* 3 */
	Array("char"=>Array(
		Array(0,9,9,9,0),
		Array(0,0,0,0,9),
		Array(0,0,0,0,9),
		Array(0,0,9,9,0),
		Array(0,0,0,0,9),
		Array(0,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,9,9,9,0)
		), "size"=>Array(5,8)),
	
	/* 4 - DONE */
	Array("char"=>Array(
		Array(0,0,0,0,9,0),
		Array(0,0,0,9,9,0),
		Array(0,0,9,0,9,0),
		Array(0,9,0,0,9,0),
		Array(9,9,9,9,9,9),
		Array(0,0,0,0,9,0),
		Array(0,0,0,0,9,0),
		Array(0,0,0,0,9,0)
		), "size"=>Array(6,8)),
	
	/* 5 - DONE */
	Array("char"=>Array(
		Array(9,9,9,9),
		Array(9,0,0,0),
		Array(9,0,0,0),
		Array(9,9,9,0),
		Array(0,0,0,9),
		Array(0,0,0,9),
		Array(0,0,0,9),
		Array(9,9,9,0)
		), "size"=>Array(5,8)),
	
	/* 6 - DONE */
	Array("char"=>Array(
		Array(0,0,9,9,9),
		Array(0,9,0,0,0),
		Array(9,0,0,0,0),
		Array(9,9,9,9,0),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(0,9,9,9,0)
		), "size"=>Array(5,8)),
	
	/* 7 - DONE */
	Array("char"=>Array(
		Array(9,9,9,9,9),
		Array(0,0,0,0,9),
		Array(0,0,0,9,0),
		Array(0,0,0,9,0),
		Array(0,0,9,0,0),
		Array(0,0,9,0,0),
		Array(0,9,0,0,0),
		Array(0,9,0,0,0)
		), "size"=>Array(5,8)),
	
	/* 8 - DONE */
	Array("char"=>Array(
		Array(0,9,9,9,0),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(0,9,9,9,0),
		Array(9,0,0,9,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(0,9,9,9,0)
		), "size"=>Array(5,8)),
	
	/* 9 - DONE */
	Array("char"=>Array(
		Array(0,9,9,9,0),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(9,0,0,0,9),
		Array(0,9,9,9,9),
		Array(0,0,0,0,9),
		Array(0,0,0,9,0),
		Array(0,9,9,0,0)
		), "size"=>Array(5,8)),

	/* _ - DONE */
	Array("char"=>Array(
		Array(9,9,9,9,9,9)
		), "size"=>Array(6,1)),

	/* - - DONE */
	Array("char"=>Array(
		Array(9,9,9)
		), "size"=>Array(3,1)),
		
	/* . - DONE */
	Array("char"=>Array(
		Array(9)
		), "size"=>Array(1,1))
);
?>

