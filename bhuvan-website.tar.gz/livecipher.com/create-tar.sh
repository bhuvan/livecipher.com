tar -zcvf bhuvan-website.tar.gz create-tar.sh update-livecipher.sh about.html contact.html contrib.html js/ images/ index.html css/
