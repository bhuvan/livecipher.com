sh create-tar.sh
rsync -av --rsh=/usr/bin/ssh . livecipher.com:~/public_html/
