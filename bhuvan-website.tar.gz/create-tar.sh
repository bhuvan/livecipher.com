tar -zcvf bhuvan-website.tar.gz create-tar.sh update-livecipher.sh about.html bhuvan-facebook-2.gif cc.gif contact.html contrib.html image.jpg index.html menu.css style.css
